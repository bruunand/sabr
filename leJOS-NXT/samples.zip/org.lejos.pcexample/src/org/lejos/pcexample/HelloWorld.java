package org.lejos.pcexample;

import lejos.nxt.Sound;

public class HelloWorld {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		//Make the NXT beep
		Sound.beep();
	}

}
